#!/bin/sh

# time zone to set
TIME_ZONE=UTC
# full Google account name, with "@gmail.com"
GDRIVE_USER=
GDRIVE_PASSWORD=
# Google Drive file name
GDRIVE_FILE_NAME="kk-plug.txt"
# how often we need to update state on Google Drive, in minutes
GDRIVE_UPDATE_PERIOD=5

###############################

tar xzf data.tar.gz

tar xz -C / -f data/opkg.tar.gz

opkg install data/libpolarssl.ipk
opkg install data/libcurl.ipk
opkg install data/curl.ipk

rm -f /etc/TZ
echo $TIME_ZONE > /etc/TZ

mkdir /www/cgi-bin
cp data/relay.cgi /www/cgi-bin

echo "username=$GDRIVE_USER" > /etc/gdrive.conf
echo "password=$GDRIVE_PASSWORD" >> /etc/gdrive.conf
echo "file_name=$GDRIVE_FILE_NAME" >> /etc/gdrive.conf
echo "update_period=$GDRIVE_UPDATE_PERIOD" >> /etc/gdrive.conf
cp data/gdrive-update.sh /usr/bin

sed -ie '/^exit/d' /etc/rc.local
echo "sh /usr/bin/gdrive-update.sh &" >> /etc/rc.local

reboot
